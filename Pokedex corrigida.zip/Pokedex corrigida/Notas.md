# Grupo: João Gabriel Eloi Brasil Da Silveira e Rafael Lira Homem Egas

## Eu usei o lint do Air-bnb como base, porém ele sempre dava erro nos documents/alerts/funções que são usada no html, então eu desisti e comecei a usar os ensinamentos da aula.

## Usei a inteligência artificial(GPT-4.1) para explicar a função(linha por linha) das seguintes functions:
# navegacao(Nome antigo: UNIFOR);
# pesquisaPokemon(Nome antigo: l)
# detalhesPokemon(Nome antigo: Minhe_nha)

## Usei a inteligência artificial(GPT-4.1) para alterar os nomes das funções no arquivo HTML, já tinha terminado de ajeitar as funções no arquivo app.js/server.js, para agilizar minha atividade usei a IA para colocar os nomes das funções em seus respectivos lugares.

## Eu tentei alterar "i" utilizado nos laços, mas quando eu mudava, o codigo falhava, então deixei como está (tentei de forma global e local).

# 
